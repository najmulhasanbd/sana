<?php $__env->startSection('title', 'নতুন সরবরাহকারী যোগ করুন'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header & Breadcrumb -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark" style="letter-spacing: -0.3px;">
                <i class="fa-solid fa-truck-ramp-box text-primary me-2"></i>নতুন হ্যাচারি সরবরাহকারী যোগ
            </h4>
            <p class="text-muted mb-0" style="font-size: 0.85rem;">
                পোনা বা মাছ সরবরাহকারী নতুন হ্যাচারির নাম, মোবাইল ও অন্যান্য বিবরণ যুক্ত করুন
            </p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 px-3 py-2 bg-white rounded-pill shadow-sm" style="font-size: 0.8rem;">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none text-muted">ড্যাশবোর্ড</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.supplier.index')); ?>" class="text-decoration-none text-muted">সরবরাহকারী তালিকা</a></li>
                    <li class="breadcrumb-item active text-primary fw-semibold" aria-current="page">নতুন যোগ</li>
                </ol>
            </nav>
            <a href="<?php echo e(route('admin.supplier.index')); ?>" class="btn btn-light border rounded-pill px-3 py-2 text-secondary fw-semibold shadow-sm d-flex align-items-center gap-1.5" style="font-size: 0.85rem;">
                <i class="fa-solid fa-arrow-left"></i>
                <span>তালিকায় ফিরে যান</span>
            </a>
        </div>
    </div>

    <!-- Form Card (Full Width) -->
    <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden w-100">
                <div class="card-header bg-white border-bottom p-3 p-md-4">
                    <h5 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                        <i class="fa-solid fa-pen-fancy text-primary"></i>
                        <span>সরবরাহকারীর তথ্যাবলী</span>
                    </h5>
                </div>

                <div class="card-body p-3 p-md-4">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-4 p-3" role="alert">
                            <div class="d-flex align-items-center mb-1">
                                <i class="fa-solid fa-triangle-exclamation text-danger me-2"></i>
                                <strong class="text-danger">নিম্নোক্ত ত্রুটিগুলো সংশোধন করুন:</strong>
                            </div>
                            <ul class="mb-0 ps-4 text-danger" style="font-size: 0.88rem;">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.supplier.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="row g-3">
                            <!-- Supplier Name -->
                            <div class="col-12 col-md-6">
                                <label for="name" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    সরবরাহকারী / হ্যাচারির নাম <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 text-muted">
                                        <i class="fa-solid fa-building"></i>
                                    </span>
                                    <input type="text" 
                                           class="form-control bg-light border-start-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="name" 
                                           name="name" 
                                           value="<?php echo e(old('name')); ?>" 
                                           placeholder="যেমন: মা ফাতেমা ফিশ হ্যাচারি" 
                                           required>
                                </div>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Mobile -->
                            <div class="col-12 col-md-6">
                                <label for="mobile" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    মোবাইল নম্বর <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 text-muted">
                                        <i class="fa-solid fa-phone"></i>
                                    </span>
                                    <input type="text" 
                                           class="form-control bg-light border-start-0 <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="mobile" 
                                           name="mobile" 
                                           value="<?php echo e(old('mobile')); ?>" 
                                           placeholder="যেমন: 017xxxxxxxx" 
                                           required>
                                </div>
                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Email -->
                            <div class="col-12 col-md-6">
                                <label for="email" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    ইমেইল ঠিকানা <small class="text-muted">(ঐচ্ছিক)</small>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 text-muted">
                                        <i class="fa-solid fa-envelope"></i>
                                    </span>
                                    <input type="email" 
                                           class="form-control bg-light border-start-0 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="email" 
                                           name="email" 
                                           value="<?php echo e(old('email')); ?>" 
                                           placeholder="যেমন: hatchery@gmail.com">
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Status -->
                            <div class="col-12 col-md-6">
                                <label class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    বর্তমান স্ট্যাটাস
                                </label>
                                <div class="d-flex align-items-center gap-4 pt-2">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" 
                                               type="checkbox" 
                                               role="switch" 
                                               id="statusSwitch" 
                                               name="status" 
                                               value="1" 
                                               <?php echo e(old('status', '1') == '1' ? 'checked' : ''); ?> 
                                               style="width: 2.5rem; height: 1.3rem; cursor: pointer;">
                                        <label class="form-check-label ms-2 fw-semibold text-success" for="statusSwitch" id="statusLabel">
                                            সক্রিয় (Active)
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Location: Division, District, Zone -->
                            <div class="col-12 col-md-4">
                                <label for="divisionSelect" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    বিভাগ (Division) <small class="text-muted">(ঐচ্ছিক)</small>
                                </label>
                                <select name="division_id" id="divisionSelect" class="select2 form-select" data-placeholder="-- বিভাগ নির্বাচন করুন --">
                                    <option value="">-- বিভাগ নির্বাচন করুন --</option>
                                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($div->id); ?>" <?php echo e(old('division_id') == $div->id ? 'selected' : ''); ?>>
                                            <?php echo e($div->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['division_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 col-md-4">
                                <label for="districtSelect" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    জেলা (District) <small class="text-muted">(ঐচ্ছিক)</small>
                                </label>
                                <select name="district_id" id="districtSelect" class="select2 form-select" data-placeholder="-- জেলা নির্বাচন করুন --">
                                    <option value="">-- জেলা নির্বাচন করুন --</option>
                                    <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dist->id); ?>" data-division-id="<?php echo e($dist->division_id); ?>" <?php echo e(old('district_id') == $dist->id ? 'selected' : ''); ?>>
                                            <?php echo e($dist->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['district_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12 col-md-4">
                                <label for="zoneSelect" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    জোন / উপজেলা (Zone) <small class="text-muted">(ঐচ্ছিক)</small>
                                </label>
                                <select name="zone_id" id="zoneSelect" class="select2 form-select" data-placeholder="-- জোন নির্বাচন করুন --">
                                    <option value="">-- জোন নির্বাচন করুন --</option>
                                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($z->id); ?>" data-district-id="<?php echo e($z->district_id); ?>" <?php echo e(old('zone_id') == $z->id ? 'selected' : ''); ?>>
                                            <?php echo e($z->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['zone_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Address -->
                            <div class="col-12">
                                <label for="address" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    ঠিকানা / লোকেশন <small class="text-muted">(ঐচ্ছিক)</small>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 text-muted align-items-start pt-2">
                                        <i class="fa-solid fa-location-dot"></i>
                                    </span>
                                    <textarea class="form-control bg-light border-start-0 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="address" 
                                              name="address" 
                                              rows="2" 
                                              placeholder="যেমন: ত্রিশাল, ময়মনসিংহ"><?php echo e(old('address')); ?></textarea>
                                </div>
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Note -->
                            <div class="col-12">
                                <label for="note" class="form-label fw-semibold text-dark" style="font-size: 0.88rem;">
                                    মন্তব্য বা বিশেষ নোট <small class="text-muted">(ঐচ্ছিক)</small>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 text-muted align-items-start pt-2">
                                        <i class="fa-solid fa-note-sticky"></i>
                                    </span>
                                    <textarea class="form-control bg-light border-start-0 <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="note" 
                                              name="note" 
                                              rows="3" 
                                              placeholder="যেমন: পাঙ্গাশ ও রুই পোনা সরবরাহের নির্ভরযোগ্য সোর্স"><?php echo e(old('note')); ?></textarea>
                                </div>
                                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1" style="font-size: 0.78rem;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Buttons with Spinner -->
                            <div class="col-12 d-flex justify-content-end gap-2 pt-3 border-top mt-4">
                                <a href="<?php echo e(route('admin.supplier.index')); ?>" class="btn btn-light border px-4 py-2.5 rounded-3 fw-semibold text-secondary">
                                    বাতিল
                                </a>
                                <button type="submit" 
                                        class="btn btn-primary px-4 py-2.5 rounded-3 fw-semibold shadow-sm d-flex align-items-center gap-2 btn-submit-with-spinner" 
                                        data-loading-text="সংরক্ষণ হচ্ছে...">
                                    <span class="btn-spinner d-none spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    <i class="fa-solid fa-check"></i>
                                    <span class="btn-text">সংরক্ষণ করুন</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        const statusSwitch = document.getElementById('statusSwitch');
        const statusLabel = document.getElementById('statusLabel');

        if (statusSwitch && statusLabel) {
            statusSwitch.addEventListener('change', function() {
                if (this.checked) {
                    statusLabel.textContent = 'সক্রিয় (Active)';
                    statusLabel.className = 'form-check-label ms-2 fw-semibold text-success';
                } else {
                    statusLabel.textContent = 'নিষ্ক্রিয় (Inactive)';
                    statusLabel.className = 'form-check-label ms-2 fw-semibold text-secondary';
                }
            });
        }

        // Cascading Division -> District -> Zone
        const $division = $('#divisionSelect');
        const $district = $('#districtSelect');
        const $zone = $('#zoneSelect');

        const districtOptions = $district.find('option').clone();
        const zoneOptions = $zone.find('option').clone();

        $division.on('change', function() {
            const divId = $(this).val();

            $district.empty().append('<option value="">-- জেলা নির্বাচন করুন --</option>');
            $zone.empty().append('<option value="">-- জোন নির্বাচন করুন --</option>');

            if (divId) {
                districtOptions.each(function() {
                    const $opt = $(this);
                    if ($opt.val() && $opt.data('division-id') == divId) {
                        $district.append($opt.clone());
                    }
                });
            } else {
                districtOptions.each(function() {
                    if ($(this).val()) {
                        $district.append($(this).clone());
                    }
                });
            }
            $district.val('').trigger('change.select2');
            $zone.val('').trigger('change.select2');
        });

        $district.on('change', function() {
            const distId = $(this).val();

            $zone.empty().append('<option value="">-- জোন নির্বাচন করুন --</option>');

            if (distId) {
                zoneOptions.each(function() {
                    const $opt = $(this);
                    if ($opt.val() && $opt.data('district-id') == distId) {
                        $zone.append($opt.clone());
                    }
                });
            } else {
                zoneOptions.each(function() {
                    if ($(this).val()) {
                        $zone.append($(this).clone());
                    }
                });
            }
            $zone.val('').trigger('change.select2');
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sana\resources\views/admin/pages/supplier/create.blade.php ENDPATH**/ ?>