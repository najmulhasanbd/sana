<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <?php if (isset($component)) { $__componentOriginalc495e9bf3210472aa4ee58cd56e3c096 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc495e9bf3210472aa4ee58cd56e3c096 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-spinner-script','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-spinner-script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc495e9bf3210472aa4ee58cd56e3c096)): ?>
<?php $attributes = $__attributesOriginalc495e9bf3210472aa4ee58cd56e3c096; ?>
<?php unset($__attributesOriginalc495e9bf3210472aa4ee58cd56e3c096); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc495e9bf3210472aa4ee58cd56e3c096)): ?>
<?php $component = $__componentOriginalc495e9bf3210472aa4ee58cd56e3c096; ?>
<?php unset($__componentOriginalc495e9bf3210472aa4ee58cd56e3c096); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\sana\resources\views/layouts/app.blade.php ENDPATH**/ ?>