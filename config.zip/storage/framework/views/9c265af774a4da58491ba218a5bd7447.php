<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['position' => 'bottom-right', 'duration' => 5000, 'animation' => 'slide', 'progress' => true, 'maxToasts' => 0]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['position' => 'bottom-right', 'duration' => 5000, 'animation' => 'slide', 'progress' => true, 'maxToasts' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (! $__env->hasRenderedOnce('258c6aab-8cdd-48c4-937d-26c78bbe7599')): $__env->markAsRenderedOnce('258c6aab-8cdd-48c4-937d-26c78bbe7599'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <style>
        .custom-toastr-wrapper {
            font-family: "Roboto", sans-serif;
            font-weight: 700;
        }

        .custom-toastr-wrapper * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .custom-toastr-list {
            position: fixed;
            z-index: 9999;
            list-style: none;
            display: flex;
            flex-direction: column;
        }

        /* Positions */
        .pos-top-right { top: 2rem; right: 2rem; }
        .pos-bottom-right { bottom: 2rem; right: 2rem; }
        .pos-top-left { top: 2rem; left: 2rem; }
        .pos-bottom-left { bottom: 2rem; left: 2rem; }
        .pos-top-center { top: 2rem; left: 50%; transform: translateX(-50%); align-items: center; }
        .pos-bottom-center { bottom: 2rem; left: 50%; transform: translateX(-50%); align-items: center; }

        .custom-toastr-item {
            position: relative;
            width: 22rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            justify-content: flex-start;
            background-color: white;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin: 0.5rem 0;
            padding: 1rem;
            opacity: 0;
            cursor: pointer; /* Click to close */
        }
        
        /* Anim: Slide (Default) */
        .custom-toastr-item.anim-slide {
            transition: all 0.4s ease;
        }
        .pos-top-right .custom-toastr-item.anim-slide,
        .pos-bottom-right .custom-toastr-item.anim-slide { transform: translateX(100%); }
        .pos-top-left .custom-toastr-item.anim-slide,
        .pos-bottom-left .custom-toastr-item.anim-slide { transform: translateX(-100%); }
        .pos-top-center .custom-toastr-item.anim-slide { transform: translateY(-100%); }
        .pos-bottom-center .custom-toastr-item.anim-slide { transform: translateY(100%); }

        .custom-toastr-item.anim-slide.visible {
            transform: translate(0, 0) !important;
            opacity: 1;
        }
        
        /* Anim: Fade */
        .custom-toastr-item.anim-fade {
            transition: opacity 0.5s ease;
            transform: translate(0, 0); /* Static position */
        }
        .custom-toastr-item.anim-fade.visible {
            opacity: 1;
        }
        
        /* Anim: Zoom */
        .custom-toastr-item.anim-zoom {
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            transform: scale(0.5);
            transform-origin: center;
        }
        .custom-toastr-item.anim-zoom.visible {
            transform: scale(1);
            opacity: 1;
        }

        .custom-toastr-icon {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .custom-toastr-icon i {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            width: 36px;
            height: 36px;
            color: #fff !important;
            border-radius: 50%;
        }

        .custom-toastr-item-container {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-right: 1.5rem;
        }

        .custom-toastr-title {
            font-size: 1rem;
            margin-bottom: 0.25rem;
            font-weight: 700;
        }

        .custom-toastr-info {
            font-size: 0.8rem;
            color: rgba(0, 0, 0, 0.75);
            line-height: 1.4;
        }

        .custom-toastr-close {
            position: absolute;
            top: 0.5rem;
            right: 0.5rem;
            border: none;
            background-color: transparent;
            font-size: 1.2rem;
            color: rgba(0, 0, 0, 0.3);
            cursor: pointer;
        }

        .custom-toastr-close:hover {
            color: black;
        }

        .custom-toastr-timeline {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 4px;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            transform-origin: left;
        }

        @keyframes custom-toastr-countdown {
            to { transform: scaleX(0); }
        }

        .custom-toastr-animate {
            animation-name: custom-toastr-countdown;
            animation-timing-function: linear;
            animation-fill-mode: forwards;
        }
    </style>
<?php endif; ?>

<div class="custom-toastr-wrapper" id="custom-toastr-wrapper">
</div>

<template id="custom-toastr-template">
    <li class='custom-toastr-item'>
        <span class='custom-toastr-icon'></span>
        <div class='custom-toastr-item-container'>
            <!-- Title will be injected here if present -->
            <p class='custom-toastr-info'></p>
        </div>
        <button class='custom-toastr-close'>x</button>
        <div class='custom-toastr-timeline'></div>
    </li>
</template>

<?php if (! $__env->hasRenderedOnce('c3a90214-6224-4227-b4f8-00d8d5f1a88c')): $__env->markAsRenderedOnce('c3a90214-6224-4227-b4f8-00d8d5f1a88c'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const wrapper = document.getElementById('custom-toastr-wrapper');
            const template = document.getElementById('custom-toastr-template');
            
            // Blade defaults
            const defaultPosition = "<?php echo e($position); ?>";
            const defaultDuration = parseInt("<?php echo e($duration); ?>") || 5000;
            const defaultAnimation = "<?php echo e($animation); ?>";
            const showProgress = <?php echo e($progress ? 'true' : 'false'); ?>;
            const maxToasts = parseInt("<?php echo e($maxToasts); ?>") || 0;

            const notificationStyles = {
                Success: { icon: '<i class="fa-solid fa-check" style="background-color: #198754;"></i>', color: '#198754' },
                Error: { icon: '<i class="fa-solid fa-xmark" style="background-color: #DC3545;"></i>', color: '#DC3545' },
                Warning: { icon: '<i class="fa-solid fa-triangle-exclamation" style="background-color: #FFC107;"></i>', color: '#FFC107' },
                Info: { icon: '<i class="fa-solid fa-circle-info" style="background-color: #0DCAF0;"></i>', color: '#0DCAF0' },
            };

            function getListContainer(pos) {
                let list = wrapper.querySelector(`.custom-toastr-list.pos-${pos}`);
                if (!list) {
                    list = document.createElement('ul');
                    list.className = `custom-toastr-list pos-${pos}`;
                    wrapper.appendChild(list);
                }
                return list;
            }
            
            function enforceMaxLimit(list, isTop) {
                if (maxToasts > 0 && list.children.length > maxToasts) {
                    // Remove oldest toast
                    const toastToRemove = isTop ? list.lastElementChild : list.firstElementChild;
                    if (toastToRemove) {
                        toastToRemove.classList.remove('visible');
                        setTimeout(() => toastToRemove.remove(), 400);
                    }
                }
            }

            function showToast(type, msg, title = null, position = null, duration = null) {
                const clone = template.content.cloneNode(true);
                const item = clone.querySelector('.custom-toastr-item');
                
                const finalPosition = position || defaultPosition;
                const finalDuration = duration ? parseInt(duration) : defaultDuration;
                
                // Add Animation class
                item.classList.add(`anim-${defaultAnimation}`);
                
                const { icon, color } = notificationStyles[type];
                
                item.querySelector('.custom-toastr-icon').innerHTML = icon;
                
                const container = item.querySelector('.custom-toastr-item-container');
                if (title) {
                    const titleEl = document.createElement('strong');
                    titleEl.className = 'custom-toastr-title';
                    titleEl.textContent = title;
                    titleEl.style.color = color;
                    container.prepend(titleEl);
                }
                
                item.querySelector('.custom-toastr-info').textContent = msg;

                const timeline = item.querySelector('.custom-toastr-timeline');
                if (showProgress) {
                    timeline.style.backgroundColor = color;
                    timeline.style.animationDuration = finalDuration + 'ms';
                    timeline.classList.add('custom-toastr-animate');
                } else {
                    timeline.style.display = 'none';
                }

                // Click to close functionality
                item.addEventListener('click', function(e) {
                    item.classList.remove('visible');
                    setTimeout(() => item.remove(), 400); 
                });

                const list = getListContainer(finalPosition);

                const isTop = finalPosition.includes('top');
                if (isTop) {
                    list.prepend(item);
                } else {
                    list.appendChild(item);
                }

                const appendedItem = isTop ? list.firstElementChild : list.lastElementChild;

                setTimeout(() => appendedItem.classList.add('visible'), 10);
                
                enforceMaxLimit(list, isTop);
                
                setTimeout(() => {
                    if (appendedItem && appendedItem.classList.contains('visible')) {
                        appendedItem.classList.remove('visible');
                    }
                }, finalDuration);
                
                setTimeout(() => {
                    if (appendedItem && appendedItem.parentNode) {
                        appendedItem.remove();
                    }
                }, finalDuration + 500);
            }

            window.customToastr = showToast;

            <?php if(session()->has('custom_toastr_messages')): ?>
                <?php $__currentLoopData = session('custom_toastr_messages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    showToast(
                        "<?php echo addslashes($toast['type']); ?>", 
                        "<?php echo addslashes($toast['message']); ?>", 
                        <?php echo !empty($toast['title']) ? "'".addslashes($toast['title'])."'" : 'null'; ?>, 
                        <?php echo !empty($toast['position']) ? "'".addslashes($toast['position'])."'" : 'null'; ?>, 
                        <?php echo !empty($toast['duration']) ? (int)$toast['duration'] : 'null'; ?>

                    );
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sana\vendor\najmulhasanbd\laravel-custom-toastr\resources\views/components/toastr.blade.php ENDPATH**/ ?>